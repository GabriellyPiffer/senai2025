

const btnMenu = document.querySelector("#btn-menu");
const menuLateral = document.querySelector("#menu-lateral");

btnMenu.addEventListener("click", () => {
    if (menuLateral.style.left === "" || menuLateral.style.left === "-200px") {
        menuLateral.style.left = "0";
    } else {
        menuLateral.style.left = "-200px";
    }
});



const consultas = [
    {
        "id": 1,
        "paciente_nome": "Ana Costa",
        "telefone": "(11) 99999-1234",
        "medico_nome": "Dra. Camila",
        "especialidade": "Cardiologia",
        "data": "2024-09-25",
        "hora": "14:00",
        "status": "agendada"
    },
    {
        "id": 2,
        "paciente_nome": "Jose Silva",
        "telefone": "(11) 98888-5678",
        "medico_nome": "Dr. Rodrigo",
        "especialidade": "Clinico Geral",
        "data": "2024-09-26",
        "hora": "09:30",
        "status": "finalizada"
    },
    {
        "id": 3,
        "paciente_nome": "Maria Lima",
        "telefone": "(11) 97777-4321",
        "medico_nome": "Dra. Camila",
        "especialidade": "Cardiologia",
        "data": "2024-09-27",
        "hora": "10:15",
        "status": "em andamento"
    },
    {
        "id": 4,
        "paciente_nome": "Carlos Pereira",
        "telefone": "(11) 96666-1111",
        "medico_nome": "Dr. Rodrigo",
        "especialidade": "Clinico Geral",
        "data": "2024-09-28",
        "hora": "15:00",
        "status": "agendada"
    },
    {
        "id": 5,
        "paciente_nome": "Julia Souza",
        "telefone": "(11) 95555-8888",
        "medico_nome": "Dr. Bruno",
        "especialidade": "Ortopedia",
        "data": "2024-09-29",
        "hora": "13:45",
        "status": "agendada"
    }
];



if (document.querySelector(".box")) {

    const boxModelo = document.querySelector(".box");
    const main = document.querySelector("main");

    consultas.forEach(c => {
        const novo = boxModelo.cloneNode(true);
        novo.style.display = "block";

        novo.querySelector(".nome").textContent = c.paciente_nome;
        novo.querySelector(".telefone").textContent = "Telefone: " + c.telefone;
        novo.querySelector(".medico").textContent = "Médico(a): " + c.medico_nome;
        novo.querySelector(".especialidade").textContent = "Especialidade: " + c.especialidade;
        novo.querySelector(".data").textContent = `Data: ${formatarData(c.data)} às ${c.hora}`;
        novo.querySelector(".status").textContent = "Status: " + c.status;

        main.appendChild(novo);
    });

    boxModelo.remove(); 
}



if (document.querySelector("#totalGeral")) {

    
    document.querySelector("#totalGeral").textContent = consultas.length;

    
    const listaStatus = document.querySelector("#totalStatus");
    const contStatus = {};

    consultas.forEach(c => {
        contStatus[c.status] = (contStatus[c.status] || 0) + 1;
    });

    for (let status in contStatus) {
        const li = document.createElement("li");
        li.textContent = `${status}: ${contStatus[status]}`;
        listaStatus.appendChild(li);
    }

   
    const listaEsp = document.querySelector("#totalEspecialidade");
    const contEsp = {};

    consultas.forEach(c => {
        contEsp[c.especialidade] = (contEsp[c.especialidade] || 0) + 1;
    });

    for (let esp in contEsp) {
        const li = document.createElement("li");
        li.textContent = `${esp}: ${contEsp[esp]}`;
        listaEsp.appendChild(li);
    }
}



function formatarData(data) {
    const [ano, mes, dia] = data.split("-");
    return `${dia}/${mes}/${ano}`;
}