require("dotenv").config();
const express = require('express');
const app = express();
const port = 3000;

const loginRoutes = require('./src/routes/login');
const pacienteRoutes = require('./src/routes/paciente');
const consultaRoutes = require('./src/routes/consulta');

app.use(express.json());

app.use(loginRoutes);
app.use(pacienteRoutes);
app.use(consultaRoutes);

app.listen(port, () => {
    console.log('listening on ' + port);
})