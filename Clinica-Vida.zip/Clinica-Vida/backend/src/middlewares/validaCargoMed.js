const validaCargoMed = (req, res, next) => {
    const cargo = req.user?.cargo;

    console.log(req.user);

    if (cargo === "medico" || cargo === "atendente" || cargo === "administrador") {
        next();
    } else {
        res.status(401).send("Sem nível de acesso").end();
    }
};


module.exports = {
    validaCargoMed
}