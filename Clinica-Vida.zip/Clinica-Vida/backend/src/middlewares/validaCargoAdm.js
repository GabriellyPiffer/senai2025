const validaCargoAdm = (req, res, next) => {
    const cargo = req.headers['user'].cargo;

    if (cargo === "administrador") {
        next();
    } else {
        res.status(401).send("Sem nível de acesso").end();
    }
};


module.exports = {
    validaCargoAdm
}