const loginController = require('../controllers/login');

const express = require('express');
const validate = require('../middlewares/auth');
const { validaCargoAdm } = require('../middlewares/validaCargoAdm');

const loginRoutes = express.Router();

loginRoutes.post('/login', loginController.Login);
loginRoutes.post("/cadastrar/usuario", validate, validaCargoAdm, loginController.cadastrarusuario);
loginRoutes.put("/usuario", validate, validaCargoAdm, loginController.editarUsuario);
loginRoutes.delete("/usuario/:id", validate, validaCargoAdm, loginController.excluiraUsuario);


module.exports = loginRoutes;