const consultaController = require('../controllers/consulta');

const express = require('express');
const validate = require('../middlewares/auth');
const { validaCargoAdm } = require('../middlewares/validaCargoAdm');
const { validaCargoAtend } = require('../middlewares/validaCargoAtend');
const { validaCargoMed } = require('../middlewares/validaCargoMed');


const consultaRoutes = express.Router();


consultaRoutes.get('/consultas', validate, validaCargoAdm,  consultaController.listarConsulta);
consultaRoutes.post("/cadastrar", validate, validaCargoAtend, consultaController.cadastrarConsulta);
consultaRoutes.put("/consulta", validate, validaCargoAdm, consultaController.editarConsulta);
consultaRoutes.delete("/consulta/:id_consulta", validate, validaCargoAdm, consultaController.excluirConsulta);



module.exports = consultaRoutes;