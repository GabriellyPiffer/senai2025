const pacienteController = require('../controllers/pacientes');

const express = require('express');
const validate = require('../middlewares/auth');
const { validaCargoAdm } = require('../middlewares/validaCargoAdm');
const { validaCargoAtend } = require('../middlewares/validaCargoAtend');
const { validaCargoMed } = require('../middlewares/validaCargoMed');


const pacienteRoutes = express.Router();

pacienteRoutes.get('/pacientes', validate, validaCargoAdm, pacienteController.listarPaciente);
pacienteRoutes.post("/paciente/cadastrar", validate, validaCargoAtend, pacienteController.cadastrarPaciente);
pacienteRoutes.put("/paciente", validate, validaCargoAdm, validaCargoAtend, pacienteController.editarPaciente);
pacienteRoutes.delete("/paciente/:id_paciente", validate, validaCargoAdm, pacienteController.excluirPaciente);

module.exports = pacienteRoutes;