const db = require("../data/connection");

const listarConsulta = async (req, res) => {
        const lista = await db.query("SELECT * FROM consulta");
    res.json(lista[0]).end();
}

const cadastrarConsulta = async (req, res) => {
    const { id_paciente, id_doutor, data, hora, status } = req.body;

    try {
        const novaconsulta = await db.query(
            "INSERT INTO consulta VALUES (DEFAULT, ?, ?, ?, ?, ?);",
            [id_paciente, id_doutor, data, hora, status]
        );

        res.send({
            id: novaconsulta[0].insertId,
            id_paciente,
            id_doutor,
            data,
            hora,
            status
        }).end();
    } catch (error) {
        console.error("Erro ao cadastrar consulta:", error);
        res.status(500).send({ erro: "Erro ao cadastrar consulta" }).end();
    }
};

const editarConsulta = async (req, res) => {
    const { id_consulta, id_paciente, id_doutor, data, hora, status } = req.body;

    try {
        const atualiza = await db.query(
            "UPDATE consulta SET id_paciente = ?, id_doutor = ?, data = ?, hora = ?, status = ? WHERE id_consulta = ?",
            [id_paciente, id_doutor, data, hora, status, id_consulta]
        );

        const info = { msg: "" };

        if (atualiza[0].affectedRows === 0) {
            info.msg = "Nenhuma consulta encontrada";
        } else if (atualiza[0].affectedRows === 1) {
            info.msg = "Consulta atualizada com sucesso";
        }

        res.status(200).json(info).end();
    } catch (error) {
        console.error("Erro ao editar consulta:", error);
        res.status(500).end();
    }
};

const excluirConsulta = async (req, res) => {
    const idConsulta = req.params.id_consulta;

    try {
        const delConsulta = await db.query("DELETE FROM consulta WHERE id_consulta = ?", [idConsulta]);

        const info = { msg: "" };

        if (delConsulta[0].affectedRows === 1) {
            info.msg = "Consulta excluída com sucesso";
        } else if (delConsulta[0].affectedRows === 0) {
            info.msg = "Consulta não encontrada";
        }

        res.status(200).json(info).end();
    } catch (error) {
        const info = { msg: "" };

        if (error.errno === 1451) {
            info.msg = "Consulta vinculada a outros registros";
        } else {
            info.msg = "Erro ao excluir consulta";
        }

        res.status(500).json(info).end();
    }
};




module.exports = {
    listarConsulta,
    cadastrarConsulta,
    editarConsulta,
    excluirConsulta
};