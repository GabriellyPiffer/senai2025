const db = require("../data/connection");

const listarPaciente = async (req, res) => {
        const lista = await db.query("SELECT * FROM paciente");
    res.json(lista[0]).end();
}

const cadastrarPaciente = async (req, res) => {
    const {nome, cpf, data_nascimento, telefone, email} = req.body;
    
    const novopaciente = await db.query("INSERT INTO paciente VALUES (DEFAULT, ?, ?, ?, ?, ?);", [nome, cpf, data_nascimento, telefone, email]); 

    res.send({
        id: novopaciente[0].insertId,    
        name: nome,
        cpf: cpf,
        data_nascimento: data_nascimento,
        telefone: telefone,
        email: email
    }).end();
};

const editarPaciente = async (req, res) => {
    const {id_paciente, nome, cpf, data_nascimento, telefone, email} = req.body;

    try {
        const atualiza = await db.query("UPDATE filmes SET nome = ?, cpf = ?, data_nascimento = ?, telefone = ?, email = ? WHERE id_paciente = ?", [nome, cpf, data_nascimento, telefone, email, id_paciente]);

        const info = {msg:""};

        if(atualiza[0].affectedRows === 0) {
            info.msg = "Nenhum paciente encontrado";
        }else if(atualiza[0].affectedRows ===1 ) {
            info.msg = "Paciente atualizado com sucesso";
        }

        res.status(200).json(info).end();

    } catch (error) {
        console.log(error);

        res.status(500).end();
    }
}

const excluirPaciente = async (req, res) => {
    const idPaciente = req.params.id_paciente;

    try {
        const delPaci = await db.query("DELETE FROM paciente WHERE id_paciente = ?", [idPaciente]);

        const info = {msg:""};

        if(delPaci[0].affectedRows === 1) {
            info.msg = "Excluido com secesso";
        }else if(delPaci[0].affectedRows === 0) {
            info.msg = "Pacinte não encontrado";
        }

        res.status(200).json(info).end();
    } catch (error) {
        const info = {msg:""};

        if(error.errno === 1451) {
            info.msg = "Paciente com consulta";
        }

        res.status(500).json(info).end();
    };

}


module.exports = {
    listarPaciente,
    cadastrarPaciente,
    editarPaciente,
    excluirPaciente
}