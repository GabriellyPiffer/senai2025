//biblioteca
#include <stdio.h>
#include <locale.h>
//inicio
int main(){
    setlocale(LC_ALL,"");
    float caminhão, alqueire, viagens;
    printf("Informe quantos caminhão possui:\n");
    scanf("%f", &caminhão);
    printf("infome quantos alqueires:\n");
    scanf("%f", &alqueire);
     viagens = (alqueire * 250) / (caminhão * 18);
     printf("Serão necessárias um total de %f viagens", viagens);
     return 0;
}