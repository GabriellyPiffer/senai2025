let count = 0;
const valor = document.querySelector("#valor");
const btns = document.querySelectorAll(".btn");

btns.forEach(function (btn) {
  btn.addEventListener("click", function (e) {
    const styles = e.currentTarget.classList;

    if (styles.contains("menos")) {
      count--;
    } else if (styles.contains("mais")) {
      count++;
    } else {
      count = 0;
    }

    
    if (count > 0) {
      valor.style.color = "#FADDE6";
    } else if (count < 0) {
      valor.style.color = "#B9CAD6";
    } else {
      valor.style.color = "#FEF9F7";
    }

    if (count % 10 === 0 && count <= 50 && count > 0) {
      mudarFundo(count);
    }

    valor.textContent = count;
  });
});


function mudarFundo(valor) {
  const fundos = {
   0: "#FEF9F7",
          10: "#89A8B2", 
          20: "#B3C8CF", 
          30: "#7f9173ff", 
          40: "#b2cbc2ff",
          50: "#99baccff"  
        };


  if (fundos[valor]) {
    document.body.style.backgroundColor = fundos[valor];
  }
}