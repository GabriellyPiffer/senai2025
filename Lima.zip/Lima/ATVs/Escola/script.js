const btnMenu = document.querySelector("#btn-menu");
const menuLateral = document.querySelector("#menu-lateral");

btnMenu.addEventListener("click", () => {
    /*console.log(menuLateral.style.left);*/
    if (

        menuLateral.style.left === "" ||
        menuLateral.style.left === "-200px"
     ) {
    menuLateral.style.left = "0";
   } else {
    menuLateral.style.left = "-200px";
   }
});

const produtos = [
    {
        imagem: "thomas.png",
        Nome: "Thomas Fantini",
        Turma: "2°B E.M",
        Disciplinas: "SENAI e ensino medio",
        Media: "8.5"
    },
    {
        imagem: "gaby.png",
        Nome: "Gabrielly Piffer",
        Turma: "2°B E.M",
        Disciplinas: "SENAI e ensino medio",
        Media: "10.0"
    },
     {
        imagem: "duda.png",
        Nome: "Eduarda Massaro",
        Turma: "2°B E.M",
        Disciplinas: "SENAI e ensino medio",
        Media: "9.5"
    },
     {
        imagem: "lais.png",
        Nome: "Lais Rocha",
        Turma: "2°B E.M",
        Disciplinas: "SENAI e ensino medio",
        Media: "8.5"
    }
];

const card = document.querySelector(".box");
const main = document.querySelector("main");

produtos.forEach((produto) => {
    let novoCard = card.cloneNode(true);
    
    novoCard.querySelector("img").src = produto.imagem;
   const paragrafos = novoCard.querySelectorAll(".info p");

    paragrafos[0].innerHTML = `Nome: ${produto.Nome}`;
    paragrafos[1].innerHTML = `Turma: ${produto.Turma}`;
    paragrafos[2].innerHTML = `Disciplinas: ${produto.Disciplinas}`;
    paragrafos[3].innerHTML = `Media: ${produto.Media}`;


    main.appendChild(novoCard);
});

const busca = document.querySelector("#busca");

busca.addEventListener("keyup", () => {
    main.childNodes.forEach((box) => {
        const conteudo =  box.innerHTML;
        if(conteudo){
            const nome = box.querySelector(".nome").innerHTML;
            if(nome.toLowerCase().includes(busca.value.toLowerCase())) {
                box.style.display = "block";
            }else {
                box.style.display = "none";
            }
        }
    });
});