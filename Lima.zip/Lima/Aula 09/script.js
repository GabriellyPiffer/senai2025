const selectCategria = document.querySelector("#categoria");
const inputValor = document.querySelector("#valor");
const btnFiltrar = document.querySelector("#filtrar");
const btnMenu = document.querySelector("#btn-menu");
const menuLateral = document.querySelector("#menu-lateral");

btnMenu.addEventListener("click", () => {
    /*console.log(menuLateral.style.left);*/
    if (

        menuLateral.style.left === "" ||
        menuLateral.style.left === "-200px"
     ) {
    menuLateral.style.left = "0";
   } else {
    menuLateral.style.left = "-200px";
   }
});

const produtos = [
    {
        imagem: "Anéis _ Poésie.jpg",
        nome: "Anel Poésie",
        valor: 150.90,
        categoria: "4"
    },
     {
        imagem: "Bracelete-Eclipse.jpg",
        nome: "Bracelete Eclipse",
        valor: 300.00,
        categoria: "2"
    },
     {
        imagem: "Colar-Brilho-Branco.jpg",
        nome: "Colar Brilho Branco",
        valor: 1000.00,
        categoria: "3"
    },
    {
        imagem: "anel-azul.jpg",
        nome: "Anel Sonho Azul",
        valor: 250.90,
        categoria: "4"
    },
    {
        imagem: "brinco-borboleta.jpg",
        nome: "Brinco Borboleta",
        valor: 99.99,
        categoria: "1"
    },
    {
        imagem: "colar-flor.jpg",
        nome: "Colar Flor",
        valor: 115.00,
        categoria: "3"
    },
     {
        imagem: "bracelete-coração.jpg",
        nome: "Bracelete Coração",
        valor: 85.00,
        categoria: "2"
    }
    
];

const card = document.querySelector(".box");
const main = document.querySelector("main");

var valormaximo = 0;
produtos.forEach((produto) => {
    let novoCard = card.cloneNode(true);
    
    novoCard.querySelector("img").src = produto.imagem;
    novoCard.querySelector(".nome").innerHTML = produto.nome;
    novoCard.querySelector(".valor").innerHTML = "R$ " + produto.valor;
    novoCard.querySelector(".categoria").innerHTML = produto.categoria;

    main.appendChild(novoCard);

    if(produto.valor > valormaximo){
        valormaximo = Math.round(produto.valor);
    }
});
inputValor.max = valormaximo;

const busca = document.querySelector("#busca");

busca.addEventListener("keyup", () => {
    main.childNodes.forEach((box) => {
        const conteudo =  box.innerHTML;
        if(conteudo){
            const nome = box.querySelector(".nome").innerHTML;
            if(nome.toLowerCase().includes(busca.value.toLowerCase())) {
                box.style.display = "block";
            }else {
                box.style.display = "none";
            }
        }
    });
});
btnFiltrar.addEventListener("click", (event) => {
    event.preventDefault();
    const catSel = selectCategria.value;
    const valSel = inputValor.value;

    main.childNodes.forEach((box) => {
        if (box.innerHTML) {
            const catbox = box.querySelector(".categoria").innerHTML;
            const valbox = Number(box.querySelector(".valor").innerHTML.split(" ")[1]);

            if ((catSel == 0 || catbox == catSel) && (valSel == 0 || valbox <= valSel)) {
                box.style.display = "block";
            } else {
                box.style.display = "none";
            }
        }
    });
});

inputValor.addEventListener("change", () => {
    document.querySelector("#spVal").innerHTML = "R$ " + inputValor.value;
});

