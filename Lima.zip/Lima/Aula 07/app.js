const colors = ["#2D1C7F", "#7546E8", "#C883F6", "#B0A9E5"];
const btn = document.getElementById("btn");
const color = document.querySelector(".color");

btn.addEventListener("click", function(){
    const randomNumber = getRandomNumber();
    document.body.style.backgroundColor = colors[randomNumber];
    color.textContent = colors[randomNumber];
});

function getRandomNumber() {
return Math.floor(Math.random() * colors.length);
}


