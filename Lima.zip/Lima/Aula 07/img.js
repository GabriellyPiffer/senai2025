const imagens = [
  "url('tartarugas.jpg')",
  "url('img3.jpg')",
  "url('img2.jpg')",
  "url('img1.jpg')"
];

const btn = document.getElementById("btn");

btn.addEventListener("click", function () {
  const randomIndex = getRandomNumber();
  const selectedImage = imagens[randomIndex];

  document.body.style.backgroundImage = selectedImage;
  document.body.style.backgroundSize = "cover";
  document.body.style.backgroundPosition = "center";
  document.body.style.backgroundRepeat = "no-repeat";
});

function getRandomNumber() {
  return Math.floor(Math.random() * imagens.length);
}