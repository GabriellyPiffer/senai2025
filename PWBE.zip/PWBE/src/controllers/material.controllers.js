const db = require("../data/connection");

const listarMateriais = async (req, res) => {
    const lista = await db.query("SELECT * FROM material_didatico");
    res.json(lista[0]).end();
}

const buscarMaterial = async (req, res) => {
    const idMaterial = req.params.id;
    const material = await db.query("SELECT * FROM material_didatico WHERE id =" + idMaterial);
    res.json(material[0][0]).end();
}

const cadastrarMaterial = async (req, res) => {
    const {curso_id, titulo, tipo, link} = req.body;

    try {
        const novoMaterial = await db.query("INSERT INTO material_didatico VALUES (DEFAULT, ?, ?, ?, ?)", [curso_id, titulo, tipo, link]);

        const material = {
            id: novoMaterial[0].insertId,
            curso_id: curso_id,
            titulo: titulo,
            tipo: tipo,
            link: link
    };

        res.status(200).json(material).end();

    } catch (error) {
        const info = { msg: "" };

        if (error.errno === 1451) {
            info.msg = "Falha ao cadastrar:curso inválido ou inexistente.";
        } else {
            info.msg = "Erro ao cadastrar Material Didatico.";
        }

        console.log(error);
        res.status(500).json(info).end();
    }
};




const excluirMaterial = async (req, res) => {
    const idMaterial = req.params.id;

    try {
        const delMaterial = await db.query("DELETE FROM material_didatico  WHERE id = ?", [idMaterial]);

        const info = {msg:""};

        if(delMaterial[0].affectedRows === 1) {
            info.msg = "Excluido com secesso";
        }else if(delMaterial[0].affectedRows === 0) {
            info.msg = "Material didatico não encontrado.";
        }

        res.status(200).json(info).end();
    } catch (error) {
        const info = {msg:""};

        if(error.errno === 1451) {
            info.msg = "Exclusão negada: este material está associado a outros registros.";
        }

        res.status(500).json(info).end();
    };

}

const atualizarMaterial = async(req,res) =>{
 const {curso_id, titulo, tipo, link, id} = req.body;
 try{
   const atualiza = await db.query(
     "UPDATE material_didatico SET curso_id = ?, titulo = ?, tipo = ?, link = ? WHERE id = ?", [curso_id, titulo, tipo, link, id]);
  
   const info = { msg: "" };
   if (atualiza[0].affectedRows === 0){
       info.msg = "nenhuma material didatico encontrado";
   } else if(atualiza[0].affectedRows === 1){
       info.msg = "Material didatico atualizada com sucesso";
   }
   res.status(200).json(info).end();
 }catch(error){
   console.log(error);
   res.status(500).end();
 }
};


module.exports = {
    listarMateriais,
    buscarMaterial,
    cadastrarMaterial,
    excluirMaterial,
    atualizarMaterial
};