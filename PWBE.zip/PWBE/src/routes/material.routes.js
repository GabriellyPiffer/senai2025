const express = require("express");
const router = express.Router();

const materiaisControllers = require("../controllers/material.controllers");

router.get("/materiais", materiaisControllers.listarMateriais);
router.get("/material/:id",materiaisControllers.buscarMaterial);
router.post("/material",materiaisControllers.cadastrarMaterial);
router.delete("/material/:id", materiaisControllers.excluirMaterial);
router.put("/material", materiaisControllers.atualizarMaterial)

module.exports = router;