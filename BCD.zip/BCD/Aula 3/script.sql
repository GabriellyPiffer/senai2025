CREATE DATABASE lojao; /*CRIA UMA BASE DE DADOS*/

use lojao;
create table produtoS(
id INTEGER AUTO_INCREENT PRIMARY KEY,
nome VARCHER(50) NOT NULL,
preco FLOAT NOT NULL,
descricao VARCHAR(150)
);

CREATE TABLE pedidos(
    id INTEGER AUTO_INCREMENT PRIMARY KEY,
    produto_id INTEGER,
    cliente VARCHAR(150),
    quantidade INTEGER,
    data DATETIME,
    FOREIGN KEY(produto_id) REFERENCES produto(id)
);

INSERT INTO produto(preco, nome, descricao)
VALUES (10.50, "Maquiagem", "Qualidade Galantia");

SELECT * FROM produto;

SELECT nome, preco FROM produto;

INSERT INTO produto
VALUES(DEFAULT, "Base", 6.99, "De confianssa");

SELECT * FROM produto;

SELECT * FROM produto WHERE id = 1; /* Busca os registros com id igual a 1 */

INSERT INTO pedidos 
VALUES(DEFAULT, 1, "Fulana", 2, "2025-08-20"),
(DEFAULT, 2, "Fulana", 1, "2025-08-20"),
(DEFAULT, 2, "Beltrana", 5, "2025-08-23");

SELECT * FROM pedidos;

SELECT * FROM pedidos WHERE produto_id = 1; /* todos pedidos referentes a id 1*/

SELECT * FROM pedidos WHERE cliente = "Fulana"; /* todos pedidos referentes a nome do cliente*/

SELECT * FROM pedidos WHERE data = "2025-08-23"; /* todos pedidos referentes a data do pedido*/

UPDATE pedidos /* Atualiza os registros da tabela*/
SET quantidade = 2  
WHERE id = 2;

SELECT * FROM pedidos WHERE id = 2;

UPDATE pedidos
SET quantidade = 2, data = "2025-08-21"
 WHERE id = 2;

DELETE FROM pedidos
WHERE id = 3;

/*deletar uma linha*/
SELECT * FROM pedidos;
