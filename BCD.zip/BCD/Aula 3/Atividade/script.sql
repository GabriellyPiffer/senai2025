DROP DATABASE  IF EXISTS biblioteca;
CREATE DATABASE biblioteca;

USE biblioteca;
CREATE TABLE usuarios(
id INTEGER AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(50) NOT NULL,
email VARCHAR(50) NOT NULL,
nascimento DATETIME
);

CREATE TABLE livros(
id INTEGER AUTO_INCREMENT PRIMARY KEY,
titulo VARCHAR(50) NOT NULL,
autor VARCHAR(50) NOT NULL,
publicacao INT(4)
);

CREATE TABLE emprestimos(
id INTEGER AUTO_INCREMENT PRIMARY KEY,
usuarios_id INTEGER,
livros_id INTEGER,
data_emprestimo DATETIME,
data_devolucao DATETIME,
FOREIGN KEY(usuarios_id) REFERENCES usuarios(id),
FOREIGN KEY(livros_id) REFERENCES livros(id)
);

INSERT INTO usuarios 
VALUES(DEFAULT, "Gabrielly", "gtpiffer@gmail.com","2008-06-02"),
(DEFAULT, "Livia", "liviam@gmail.com","2008-10-06"),
(DEFAULT, "Thomas", "thoto@gmail.com","2009-03-13");

SELECT * FROM usuarios;

SELECT * FROM usuarios WHERE id = 2;

INSERT INTO livros
VALUES(DEFAULT, "Dom Casmurro", "Machado de Assis","1899"),
(DEFAULT, "O Pequeno Príncipe", "Antoine de Saint-Exupéry","1943"),
(DEFAULT, "A Bela e a Fera", "Jeanne-Marie Leprince de Beaumont","1756");

SELECT * FROM livros;

SELECT * FROM livros WHERE id = 3;

INSERT INTO emprestimos
VALUES(DEFAULT, 1, 2,"2025-08-01", "2025-08-20"),
(DEFAULT, 3, 3, "2025-08-06", "2025-08-26");

SELECT * FROM emprestimos;

SELECT usuarios_id, data_emprestimo FROM emprestimos;

UPDATE emprestimos
SET data_devolucao = "2025-08-27"  
WHERE id = 2;

SELECT * FROM emprestimos;

SELECT data_devolucao FROM emprestimos;

DELETE FROM usuarios
WHERE id = 2;

SELECT * FROM usuarios;

SELECT * FROM usuarios WHERE id = 2;