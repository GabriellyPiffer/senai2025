require("dotenv").config();
const express = require('express');
const app = express();
const port = 3000;

const funcionarioRoutes = require('./src/routes/funcionario');
const projetoRoutes = require('./src/routes/projetos');
const tarefaRoutes = require('./src/routes/tarefas');

app.use(express.json());

app.use(funcionarioRoutes);
app.use(projetoRoutes);
app.use(tarefaRoutes);

app.listen(port, () => {
    console.log('listening on ' + port);
})