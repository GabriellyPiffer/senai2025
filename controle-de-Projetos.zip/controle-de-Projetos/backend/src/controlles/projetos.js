const db = require("../data/connection");

const listarprojeto = async(req, res) => {
    const projeto = await db.query ("SELECT * FROM projeto");
    res.status(200).send(projeto[0]).end();
};

const cadastrarprojeto = async (req,res)=>{
const { nome, descricao, data_inicio, data_fim} = req.body;
const novoprojeto = await db.query("INSERT INTO projeto VALUES (DEFAULT,?,?,?,?);",[nome,descricao,data_inicio,data_fim]);
res.send({
    id_projeto: novoprojeto[0].insertId,
    nome: nome,
    descricao:descricao,
    data_inicio: data_inicio,
    data_fim: data_fim,
}).end();
};
const excluirprojeo = async (req, res) => {
    const idproj = req.params.id;

    try {
        const delproj = await db.query("DELETE FROM projeto WHERE id_projeto = ?", [idproj]);

        const info = { msg: "" };

        if (delproj[0].affectedRows === 1) {
            info.msg = "Excluído com sucesso";
        } else if (delproj[0].affectedRows === 0) {
            info.msg = "Projeto não encontrado";
        }

        res.status(200).json(info).end();
    } catch (error) {
        const info = { msg: "" };

        if (error.errno === 1451) {
            info.msg = "Projeto com tarefas";
        }

        res.status(500).json(info).end();
    }
};

const atualizarprojeto = async (req, res) => {
    const { id_projeto, nome, descricao, data_inicio, data_fim } = req.body;

    try {
        const atualiza = await db.query(
            "UPDATE projeto SET nome = ?, descricao = ?, data_inicio = ?, data_fim = ? WHERE id_projeto = ?",
            [nome, descricao, data_inicio, data_fim, id_projeto]
        );

        const info = { msg: "" };

        if (atualiza[0].affectedRows === 0) {
            info.msg = "Nenhum projeto encontrado";
        } else if (atualiza[0].affectedRows === 1) {
            info.msg = "Projeto atualizado com sucesso";
        }

        res.status(200).json(info).end();

    } catch (error) {
        console.log(error);
        res.status(500).end();
    }
};

module.exports = {
    listarprojeto,
    cadastrarprojeto,
    excluirprojeo,
    atualizarprojeto
}