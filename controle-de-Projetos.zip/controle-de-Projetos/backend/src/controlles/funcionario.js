const db = require("../data/connection")
const jsonwebtoken = require("jsonwebtoken");
const crypto = require('node:crypto');

const listarfuncionario = async(req, res) => {
    const funcionario = await db.query ("SELECT * FROM funcionario");
    res.status(200).send(funcionario[0]).end();
};

const cadastrarfuncionario = async (req, res) => {
    const { nome, cargo, email, senha } = req.body;
    const novasenha = crypto.createHash("md5").update(senha).digest("hex").toString();

    const novofuncionario = await db.query("INSERT INTO funcionario VALUES (DEFAULT, ?, ?, ?, ?);", [nome, cargo, email, novasenha]); 

    res.send({
        id_funcionario: novofuncionario[0].insertId,    
        name: nome,
        cargo: cargo,
        email: email
    }).end();
};

const Login = async (req, res) => {
    const { user, psw } = req.body;
    
    try {
       const senhahash = crypto.createHash("MD5").update(psw).digest("hex").toString();

       const funcionario = await db.query("SELECT * FROM funcionario WHERE email = ? AND senha = ?;", [user,senhahash]);

        if(funcionario[0].length == 0) return res.status(401).send({message:'E-mail or Password incorrect !'});

        const token = jsonwebtoken.sign(
            {
                id_funcionario: funcionario[0][0].id,
                name: funcionario[0][0].nome,
                cargo: funcionario[0][0].cargo,
                email: funcionario[0][0].email
            },
            process.env.SECRET_JWT,
            { expiresIn: "60min" }
        );

        res.status(200).json({ token : token }).end();
    }catch(err) {
        console.log(err);
        res.status(500).send(err).end();
    }
    
    res.status(200).end();
};

const excluirfuncionario = async (req, res) => {
    const idfun = req.params.id;

    try {
        const delfun = await db.query("DELETE FROM funcionario WHERE id_funcionario = ?", [idfun]);

        const info = { msg: "" };

        if (delfun[0].affectedRows === 1) {
            info.msg = "Excluído com sucesso";
        } else if (delPost[0].affectedRows === 0) {
            info.msg = "Funcionario não encontrado";
        }

        res.status(200).json(info).end();
    } catch (error) {
        const info = { msg: "" };

        if (error.errno === 1451) {
            info.msg = "Funcionario em projeto";
        }

        res.status(500).json(info).end();
    }
};

const atualizarfuncionario = async (req, res) => {
    const { id_funcionario, nome, email, cargo } = req.body;

    try {
        const atualiza = await db.query(
            "UPDATE funcionario SET nome = ?, email = ?, cargo = ? WHERE id_funcionario = ?",
            [nome, email, cargo, id_funcionario]
        );

        const info = { msg: "" };

        if (atualiza[0].affectedRows === 0) {
            info.msg = "Nenhum funcionario encontrado";
        } else if (atualiza[0].affectedRows === 1) {
            info.msg = "funcionario atualizado com sucesso";
        }

        res.status(200).json(info).end();

    } catch (error) {
        console.log(error);
        res.status(500).end();
    }
};

module.exports = {
    listarfuncionario,
    cadastrarfuncionario,
    excluirfuncionario,
    atualizarfuncionario,
    Login,
}