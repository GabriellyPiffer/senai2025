const db = require("../data/connection");

const listartarefas = async(req, res) => {
    const tarefas = await db.query ("SELECT * FROM tarefa");
    res.status(200).send(tarefas[0]).end();
};

const cadastrartarefa = async (req,res)=>{
const {projeto_id, funcionario_id, descricao, prazo, status} = req.body;
const novatarefa = await db.query("INSERT INTO tarefa VALUES (DEFAULT,?,?,?,?,?);",[projeto_id, funcionario_id, descricao, prazo, status]);
res.send({
    id_tarefa: novatarefa[0].insertId,
    projeto_id: projeto_id,
    funcionario_id: funcionario_id,
    descricao:descricao,
    prazo: prazo,
    status: status,
}).end();
};
const excluirtarefa = async (req, res) => {
    const idtarefa = req.params.id;

    try {
        const deltarefa = await db.query("DELETE FROM tarefa WHERE id_tarefa = ?", [idtarefa]);

        const info = { msg: "" };

        if (deltarefa[0].affectedRows === 1) {
            info.msg = "Excluído com sucesso";
        } else if (deltarefa[0].affectedRows === 0) {
            info.msg = "Tarefa não encontrada";
        }

        res.status(200).json(info).end();
    } catch (error) {
        const info = { msg: "" };

        if (error.errno === 1451) {
            info.msg = "Tarefas vinculadas a um projeto";
        }

        res.status(500).json(info).end();
    }
};

const atualizartarefa = async (req, res) => {
    const { id_tarefa, projeto_id, funcionario_id, descricao, prazo, status } = req.body;

    try {
        const atualiza = await db.query(
            "UPDATE tarefa SET projeto_id = ?, funcionario_id = ?, descricao = ?, prazo = ?, status = ? WHERE id_tarefa = ?",
            [projeto_id, funcionario_id, descricao, prazo, status, id_tarefa]
        );

        const info = { msg: "" };

        if (atualiza[0].affectedRows === 0) {
            info.msg = "Nenhuma tarefa encontrado";
        } else if (atualiza[0].affectedRows === 1) {
            info.msg = "Tarefa atualizada com sucesso";
        }

        res.status(200).json(info).end();

    } catch (error) {
        console.log(error);
        res.status(500).end();
    }
};

module.exports = {
    listartarefas,
    cadastrartarefa,
    excluirtarefa,
    atualizartarefa
}