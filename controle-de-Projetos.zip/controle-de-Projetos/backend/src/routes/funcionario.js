const Controller = require("../controlles/funcionario");
const validate = require("../middlewares/auth");

const express = require('express');

const funcionarioRoutes = express.Router();


funcionarioRoutes.post('/login', Controller.Login);
funcionarioRoutes.get('/funcionarios', validate, Controller.listarfuncionario);
funcionarioRoutes.post("/cadastrar",  Controller.cadastrarfuncionario);
funcionarioRoutes.delete("/funcionario/:id", validate, Controller.excluirfuncionario);
funcionarioRoutes.put("/funcionario", validate, Controller.atualizarfuncionario);

module.exports = funcionarioRoutes;