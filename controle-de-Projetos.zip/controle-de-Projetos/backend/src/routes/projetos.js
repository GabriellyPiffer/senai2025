const Controller = require("../controlles/projetos");
const validate = require("../middlewares/auth");

const express = require('express');

const projetoRoutes = express.Router();

projetoRoutes.get('/projetos', validate, Controller.listarprojeto);
projetoRoutes.post("/cadastrar/projeto", validate, Controller.cadastrarprojeto);
projetoRoutes.delete("/projeto/:id", validate, Controller.excluirprojeo);
projetoRoutes.put("/projeto", validate, Controller.atualizarprojeto);

module.exports = projetoRoutes;