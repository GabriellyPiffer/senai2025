const Controller = require("../controlles/tarefas");
const validate = require("../middlewares/auth");

const express = require('express');

const tarefaRoutes = express.Router();

tarefaRoutes.get('/tarefas', validate, Controller.listartarefas);
tarefaRoutes.post("/cadastrar/tarefa", validate, Controller.cadastrartarefa);
tarefaRoutes.delete("/tarefa/:id", validate, Controller.excluirtarefa);
tarefaRoutes.put("/tarefa", validate, Controller.atualizartarefa);

module.exports = tarefaRoutes;