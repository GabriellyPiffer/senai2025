//Ex 1
var nome = "Gabrielly";

console.log("Olá, " + nome);
console.log("---------------------------------------------");

//Ex 2
var a = 15;
var b = 30;

console.log(a + b);
console.log(a - b);
console.log(a / b);
console.log(a * b);
console.log("---------------------------------------------");

//Ex 3
var altura = 25;
var largura = 50;
var area = altura * largura;

console.log("A área do retângulo é :" + area);
console.log("---------------------------------------------");

//Ex 4
var nascimento = 2008
var idade = nascimento - 2025

if(idade >= 18){
    console.log("Você é maior de idade");
} else{
    console.log("Você é menor de idade");
}
console.log("---------------------------------------------");

//Ex 5 
var numero = 10;
console.log("Numero = " + numero);
if (numero / 2 ) {
    console.log("O numero é par");
} else{
    console.log("O numero é impar");
}
console.log("---------------------------------------------");

//Ex 6 
var n1 = 8.5;
var n2 = 7.0;
var n3 = 9.5;
var media = (n1 + n2 + n3) / 3;

console.log("A media é: " + media);
if (media >= 9) {
    console.log("A");
} else if (media >= 7) {
    console.log("B");
} else if (media >= 5) {
    console.log("C");
} else {
    console.log("Reprovado");
}
console.log("---------------------------------------------");

//Ex 7
for (let i = 30; i >= 1; i--) {
    console.log(i);
}
console.log("---------------------------------------------");

//Ex 8
for (let i = 0; i <= 500; i+=3) {
    console.log(i);
}
console.log("---------------------------------------------");

//Ex 9
for (let i = 1; i <= 300; i++) {
    if (i % 2 === 0) {
        console.log(i);
    }
}