const express = require("express");
const cors = require("cors");

const clientesRoutes = require("./src/routes/clientes.routes");
const vendedorRoutes = require("./src/routes/vendedor.routes");
const mangaRoutes = require("./src/routes/manga.routes");
const vendasRoutes = require("./src/routes/vendas.routes");
const app = express();

app.use(express.json());
app.use(cors());

app.use(clientesRoutes);
app.use(vendedorRoutes);
app.use(mangaRoutes);
app.use(vendasRoutes);

app.listen(3000, () => {
    console.log("Servidor Online");
});