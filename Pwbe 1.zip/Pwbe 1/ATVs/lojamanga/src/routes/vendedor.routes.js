const express = require("express");
const router = express.Router();

const vendedorControllers = require("../controllers/vendedor.controllers");

router.get("/vendedores", vendedorControllers.listarVendedor);
router.get("/vendedor/:id", vendedorControllers.buscarVendedor);
router.post("/vendedor", vendedorControllers.cadastrarVendedor);
router.delete("/vendedor/:id", vendedorControllers.excluirVendedor);
router.put("/vendedor",vendedorControllers.atualizarVendedor);

module.exports = router;