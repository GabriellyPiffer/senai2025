const express = require("express");
const router = express.Router();

const vendasControllers = require("../controllers/vendas.controllers");

router.get("/vendas", vendasControllers.listarVendas);
router.get("/venda/:id", vendasControllers.buscarVenda);
router.post("/venda", vendasControllers.cadastrarVenda);
router.delete("/venda/:id", vendasControllers.excluirVenda);
router.put("/venda", vendasControllers.atualizarVenda);

module.exports = router;