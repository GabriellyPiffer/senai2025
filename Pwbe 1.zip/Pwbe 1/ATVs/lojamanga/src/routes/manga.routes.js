const express = require("express");
const router = express.Router();

const mangasControllers = require("../controllers/manga.controllers");

router.get("/mangas", mangasControllers.listarMangas);
router.get("/manga/:id", mangasControllers.buscarManga);
router.post("/manga", mangasControllers.cadastrarManga);
router.delete("/manga/:id", mangasControllers.excluirManga);
router.put("/manga", mangasControllers.atualizarManga);

module.exports = router;