const db = require("../data/connection");

const listarVendas = async (req, res) => {
    const lista = await db.query("SELECT * FROM vendas");
    res.json(lista[0]).end();
}

const buscarVenda = async (req, res) => {
    const idVenda = req.params.id;
    const venda = await db.query("SELECT * FROM vendas WHERE id = ?", [idVenda]);
    res.json(venda[0][0]).end();
}

const cadastrarVenda = async (req, res) => {
    const { cliente, vendedor, valor } = req.body;
    const novaVenda = await db.query(
        "INSERT INTO vendas VALUES (DEFAULT, ?, ?, ?)",
        [cliente, vendedor, valor]
    );

    const venda = {
        id: novaVenda[0].insertId,
        cliente,
        vendedor,
        valor
    };
    res.json(venda).status(201).end();
}

const excluirVenda = async (req, res) => {
    const idVenda = req.params.id;

    try {
        const delVenda = await db.query("DELETE FROM vendas WHERE id = ?", [idVenda]);
        const info = { msg: "" };

        if (delVenda[0].affectedRows === 1) {
            info.msg = "Excluído com sucesso";
        } else if (delVenda[0].affectedRows === 0) {
            info.msg = "Venda não encontrada";
        }

        res.status(200).json(info).end();
    } catch (error) {
        res.status(500).json({ msg: "Erro ao excluir venda" }).end();
    }
}

const atualizarVenda = async (req, res) => {
    const { id, cliente, vendedor,valor } = req.body;

    try {
        const atualiza = await db.query(
            "UPDATE vendas SET cliente = ?, vendedor = ?, valor = ? WHERE id = ?",
            [cliente, vendedor, valor, id]
        );

        const info = { msg: "" };

        if (atualiza[0].affectedRows === 0) {
            info.msg = "Nenhuma venda encontrada";
        } else if (atualiza[0].affectedRows === 1) {
            info.msg = "Venda atualizada com sucesso";
        }

        res.status(200).json(info).end();
    } catch (error) {
        res.status(500).end();
    }
}

module.exports = {
    listarVendas,
    buscarVenda,
    cadastrarVenda,
    excluirVenda,
    atualizarVenda
};