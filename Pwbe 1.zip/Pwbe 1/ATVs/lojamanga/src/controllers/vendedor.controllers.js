const db = require("../data/connection");

const listarVendedor = async (req, res) => {
    const lista = await db.query("SELECT * FROM vendedor");
    res.json(lista[0]).end();
}


const buscarVendedor = async (req, res) => {
    const idVendedor = req.params.id;
    const vendedor = await db.query("SELECT * FROM vendedor WHERE id =" + idVendedor);
    res.json(vendedor[0][0]).end();
}


const cadastrarVendedor = async (req, res) => {
    const {nome, endereco, nascimento, idade} = req.body;
    const novoVendedor = await db.query("INSERT INTO vendedor (nome, endereco, nascimento, idade) VALUES (?, ?, ?, ?)", 
  [nome, endereco, nascimento, idade]
);

    console.log(novoVendedor);

    const vendedor = {
        id: novoVendedor[0].insertId,
        nome: nome,
        endereco: endereco,
        nascimento: nascimento
        
    }
    res.json(vendedor).status(201).end();
}

const excluirVendedor = async (req, res) => {
    const idVendedor = req.params.id;

    try {
        const delVendedor = await db.query("DELETE FROM vendedor WHERE id = ?", [idVendedor]);

        const info = {msg:""};

        if(delVendedor[0].affectedRows === 1) {
            info.msg = "Excluido com secesso";
        }else if(delVendedor[0].affectedRows === 0) {
            info.msg = "Vendedor não encontrado";
        }

        res.status(200).json(info).end();
    } catch (error) {
        console.log(error);

        res.status(500).end();

}
}

const atualizarVendedor = async (req, res) => {
    const { id, nome, endereco, nascimento, idade} = req.body;

    try {
        const atualiza = await db.query("UPDATE vendedor SET nome = ?, endereco = ?, nascimento = ?, idade = ?  WHERE id = ?", [nome, endereco, nascimento, idade, id]);

        const info = {msg:""};

        if(atualiza[0].affectedRows === 0) {
            info.msg = "Nenhum cliente encontrado";
        }else if(atualiza[0].affectedRows ===1 ) {
            info.msg = "Vendedor atualizado com sucesso";
        }

        res.status(200).json(info).end();

    } catch (error) {
        console.log(error);

        res.status(500).end();
    }
}

module.exports = {
    listarVendedor,
    buscarVendedor,
    cadastrarVendedor,
    excluirVendedor,
    atualizarVendedor
};