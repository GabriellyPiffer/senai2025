const db = require("../data/connection");

const listarMangas = async (req, res) => {
    const lista = await db.query("SELECT * FROM manga");
    res.json(lista[0]).end();
}

const buscarManga = async (req, res) => {
    const idManga = req.params.id;
    const manga = await db.query("SELECT * FROM manga WHERE id = ?", [idManga]);
    res.json(manga[0][0]).end();
}

const cadastrarManga = async (req, res) => {
    const { nome, genero, classificacao } = req.body;
    const novoManga = await db.query(
        "INSERT INTO manga VALUES (DEFAULT, ?, ?, ?)",
        [nome, genero, classificacao]
    );

    const manga = {
        id: novoManga[0].insertId,
        nome,
        genero,
        classificacao
    };
    res.json(manga).status(201).end();
}

const excluirManga = async (req, res) => {
    const idManga = req.params.id;

    try {
        const delManga = await db.query("DELETE FROM manga WHERE id = ?", [idManga]);
        const info = { msg: "" };

        if (delManga[0].affectedRows === 1) {
            info.msg = "Excluído com sucesso";
        } else if (delManga[0].affectedRows === 0) {
            info.msg = "Manga não encontrado";
        }

        res.status(200).json(info).end();
    } catch (error) {
        res.status(500).json({ msg: "Erro ao excluir manga" }).end();
    }
}

const atualizarManga = async (req, res) => {
    const { id, nome, genero, classificacao } = req.body;

    try {
        const atualiza = await db.query(
            "UPDATE manga SET nome = ?, genero = ?, classificacao = ? WHERE id = ?",
            [nome, genero, classificacao, id]
        );

        const info = { msg: "" };

        if (atualiza[0].affectedRows === 0) {
            info.msg = "Nenhum manga encontrado";
        } else if (atualiza[0].affectedRows === 1) {
            info.msg = "Manga atualizado com sucesso";
        }

        res.status(200).json(info).end();
    } catch (error) {
        res.status(500).end();
    }
}

module.exports = {
    listarMangas,
    buscarManga,
    cadastrarManga,
    excluirManga,
    atualizarManga
};