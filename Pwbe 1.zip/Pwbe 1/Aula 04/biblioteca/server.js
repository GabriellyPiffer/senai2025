const express = require("express"); //importa um modulo
const cors = require("cors");

const UsuariosRoutes = require("./src/routes/usuarios.routes");
const Livrosroutes = require("./src/routes/livros.routes");

const app = express();

app.use(express.json());//habilita comunicaçãovia JSON
app.use(cors());//habilita requisição local

//importar as Rotas configuradas
app.use(UsuariosRoutes);
app.use(livrosroutes);

app.listen(3001, () => {
    console.log("Servidor online na porta 3000");
});
