const livros = require("../data/livros.data");


const listar = (req, res) => {
    res.status(201).send(livros).end();
};

const buscar = (req, res) => {
    //    /livros/id
    const idLivros = req.params.id;

    var user = "Não encontrado";

    livros.forEach((livro, index) => {
        if (livro.id === idLivro) {
            user = livro;
        }
    });

    livros.forEach((livro, index) => {
        if (livro.id === idLivro) {
            user = livro;
        }
    });

    res.send(livroencontrado).end();
}
const cadastrar = (req, res) => {
    const novolivro = req.body;
    //adicionar novo usuario
    livros.push(novolivro);
    res.send("Cadastrado com Sucesso!").end();
};
module.exports={
    listar,
    buscar,
    cadastrar
}