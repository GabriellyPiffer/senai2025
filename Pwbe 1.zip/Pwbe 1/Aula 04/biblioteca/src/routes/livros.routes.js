const express = require("express");
const router = express.Router();

const livroscontroller = require("../controllers/livros.controller");

router.get("/livros", livroscontroller.listar);
router.get("/livros/:id", livroscontroller.buscar);
router.post ("/livros", livroscontroller.cadastrar);


module.exports = router;