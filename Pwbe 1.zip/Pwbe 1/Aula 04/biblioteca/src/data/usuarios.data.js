const listar = [
    {
        "id":"123",
        "nome":"Fulano da Silva",
        "telefone":"(19)91234-5678"
    },
    {
        "id":"789",
        "nome":"Beltrano Nascimento",
        "telefone":"(19) 94568-7894"
    }
];

module.exports = usuarios;