const livros = [
    {
        "id" : "12345",
        "titulo" : "A Biblioteca da Meia-Noite"
        "autor" : "Matt Haig"
        "puplicacao" : "2021"
        "genero" : "Ficção Científica Humorística"
    },
    {
        "id" : "678910",
        "titulo" : "É Assim Que Acaba"
        "autor" : "Colleen Hoover"
        "puplicacao" : "2016"
        "genero" : "Romance"
    }
];
module.exports = livros;