
const validaSupervisor = (req, res, next) =>{
    const cargo = req.headers['user'].cargo;

    if(cargo === "Supervisor") {
        next();
    } else{
        res.status(401).send("Sem nivel de acesso").end();
    }
};

module.exports = {
    validaSupervisor
}