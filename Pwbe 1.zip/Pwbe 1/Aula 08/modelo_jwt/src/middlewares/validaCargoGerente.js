const validaGerente = (req, res, next) => {
    const cargo = req.headers['user'].cargo;

    console.log(req.headers['user']);

    if (cargo === "Gerente") {
        next();
    } else {
        res.status(401).send("Sem nível de acesso").end();
    }
};


module.exports = {
    validaGerente
}