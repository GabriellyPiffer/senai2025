const express = require("express");
const router = express.Router();

const filmesControllers = require("../controllers/filmes.controller");

router.get("/filmes", filmesControllers.listarFilmes);
router.get("/filme/:id", filmesControllers.buscarFilmes);
router.post("/filme", filmesControllers.cadastrarFilme);
router.delete("/filme/:id", filmesControllers.excluirFilme);
router.put("/filme", filmesControllers.atualizarFilme);

module.exports = router;