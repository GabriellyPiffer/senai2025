const express = require("express");
const router = express.Router();

const locacoesControllers = require("../controllers/locacoes.controllers");

router.get("/locacoes", locacoesControllers.listarLocacoes);
router.get("/locacao/:id",locacoesControllers.buscarlocacao);
router.post("/locacao", locacoesControllers.cadastrarLocacao);
router.delete("/locacao/:id", locacoesControllers.excluirLocacao);
router.put("/locacao", locacoesControllers.atualizarLocacoes);
router.get("/locacoes/cliente/:id", locacoesControllers.listarLocacoesPorCliente); 
router.get("/locacoes/status/:status", locacoesControllers.listarLocacoesPorStatus);
router.get("/locacoes/faturamento", locacoesControllers.calcularFaturamento);

module.exports = router;