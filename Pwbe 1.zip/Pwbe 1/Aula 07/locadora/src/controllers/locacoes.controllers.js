const db = require("../data/connection");

const listarLocacoes = async (req, res) => {
    const lista = await db.query("SELECT * FROM locacoes");
    res.json(lista[0]).end();
}

const buscarlocacao = async (req, res) => {
    const idlocacao = req.params.id;
    const locacao = await db.query("SELECT * FROM locacoes WHERE id =" + idlocacao);
    res.json(locacao[0][0]).end();
}

const cadastrarLocacao = async (req, res) => {
    const { cliente_id, filme_id, data_locacao, status, preco } = req.body;

    try {
        const novaLocacao = await db.query("INSERT INTO locacoes VALUES (DEFAULT, ?, ?, ?, ?, ?)", [cliente_id, filme_id, data_locacao, status, preco]);

        const locacao = {
            id: novaLocacao[0].insertId,
            cliente_id: cliente_id,
            filme_id: filme_id,
            data_locacao: data_locacao,
            status: status,
            preco: preco
        };

        res.status(200).json(locacao).end();

    } catch (error) {
        const info = { msg: "" };

        if (error.errno === 1451) {
            info.msg = "Erro locação vinculada a cliente";
        } else {
            info.msg = "Erro ao cadastrar locação";
        }

        console.log(error);
        res.status(500).json(info).end();
    }
};




const excluirLocacao = async (req, res) => {
    const idLocacao = req.params.id;

    try {
        const delLocacao = await db.query("DELETE FROM locacoes WHERE id = ?", [idLocacao]);

        const info = {msg:""};

        if(delLocacao[0].affectedRows === 1) {
            info.msg = "Excluido com secesso";
        }else if(delLocacao[0].affectedRows === 0) {
            info.msg = "Locação não encontrado";
        }

        res.status(200).json(info).end();
    } catch (error) {
        const info = {msg:""};

        if(error.errno === 1451) {
            info.msg = "locação do cliente";
        }

        res.status(500).json(info).end();
    };

}

const atualizarLocacoes = async(req,res) =>{
 const {cliente_id, filme_id, data_locacao, status, preco, id} = req.body;
 try{
   const atualiza = await db.query(
     "UPDATE locacoes SET cliente_id = ?, filme_id = ?, data_locacao = ?, status = ?, preco = ? WHERE id = ?", [cliente_id, filme_id, data_locacao, status, preco, id]);
  
   const info = { msg: "" };
   if (atualiza[0].affectedRows === 0){
       info.msg = "nenhuma locação encontrada";
   } else if(atualiza[0].affectedRows === 1){
       info.msg = "Locação atualizada com sucesso";
   }
   res.status(200).json(info).end();
 }catch(error){
   console.log(error);
   res.status(500).end();
 }
};

const listarLocacoesPorCliente = async (req, res) => {
    const idCliente = req.params.id;
    try {
        const locacoes = await db.query("SELECT * FROM locacoes WHERE cliente_id = ?", [idCliente]);
        res.status(200).json(locacoes[0]).end();
    } catch (error) {
        console.log(error);
        res.status(500).end();
    }
};



const listarLocacoesPorStatus = async (req, res) => {
    const status = req.params.status;
    try {
        const locacoes = await db.query("SELECT * FROM locacoes WHERE status = ?", [status]);
        res.status(200).json(locacoes[0]).end();
    } catch (error) {
        console.log(error);
        res.status(500).end();
    }
};

const calcularFaturamento = async (req, res) => {
    try {
        const total = await db.query("SELECT SUM(preco) AS total FROM locacoes");
        res.status(200).json(total[0][0]).end();
    } catch (error) {
        console.log(error);
        res.status(500).end();
    }
};

module.exports = {
    listarLocacoes,
    buscarlocacao,
    cadastrarLocacao,
    excluirLocacao,
    atualizarLocacoes,
    listarLocacoesPorCliente,
    listarLocacoesPorStatus,
    calcularFaturamento    
};