const express = require("express");
const router = express.Router();
const controller = require("../controllers/quarto.controllers");


router.get("/quartos", controller.listar);
router.get("/quartos/:id", controller.listarVagos);
router.get("/quartos/:id/:dias", controller.simuladorEstadia);

module.exports = router;