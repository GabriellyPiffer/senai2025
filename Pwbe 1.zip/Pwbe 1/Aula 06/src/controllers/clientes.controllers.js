const clientes = require("../data/cliente.data");

const listarTodosClientes = (req, res) => {
    res.status(200).send(clientes).end();
};

const cadastrar = (req, res) => {
    const novoCliente = req.body;
    clientes.push(novoCliente);
    res.status(201).send("Cadastrado com Sucesso!").end();
};

const ClientesComResAtiva = (req, res) => {
    const clientesAtivos = clientes.filter(cliente =>
        reservas.some(reserva => reserva.clienteId == cliente.id && reserva.checkOut === null)
    );

    if (clientesAtivos.length === 0) {
        return res.status(200).json({ "Nenhum cliente com reserva ativa no momento." });
    }

    res.status(200).json(clientesAtivos);
};

module.exports = {
    listarTodosClientes,
    cadastrar,  
    ClientesComResAtiva

 };
