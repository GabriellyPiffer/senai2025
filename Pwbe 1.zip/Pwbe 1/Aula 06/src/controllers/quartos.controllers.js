const quartos = require("../data/quarto.data");

const listar = (req, res) => {
  res.send(quartos);
};

const listarVagos = (req, res) => {
  const vagos = quartos.filter(q => !q.ocupado);
  res.send(vagos);
};

const simularEstadia = (req, res) => {
  const { id, dias } = req.body;
  const quarto = quartos.find(q => q.id === id);
  if (!quarto) {
    return res.status(404).send("Quarto não encontrado");
  }
  const total = quarto.valorDiaria * dias;
  res.json({
    id: quarto.id,
    tipo: quarto.tipo,
    dias,
    valorDiaria: quarto.valorDiaria,
    total
  });
};



module.exports = {
  listar,
  listarVagos,
  simularEstadia
};