const listar = [
    { 
        "id": "1", 
        "nome": "Gabrielly Piffer", 
        "cpf":"123456789-00", 
        "telefone":"12 91234-4567" 
    },
    { 
        "id": "2", 
        "nome": "Thomas Fantini", 
        "cpf":"987654321-00", 
        "telefone":"12 19324-5476" 
    } 
]
module.exports = listar;