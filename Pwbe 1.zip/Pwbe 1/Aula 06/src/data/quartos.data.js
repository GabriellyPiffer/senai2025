const listar  = [
    { 
        "id": "101", 
        "tipo" : "Solteiro", 
        "capacidade" : "1",
        "preco" : "120.00", 
        "ocupado" : "false"
    },
    { 
        "id" : "102", 
        "tipo" : "Casal", 
        "capacidade" : "2", 
        "preco" : "180.00", 
        "ocupado" : "true" 
    },
    { 
        "id" : "201", 
        "tipo" : "Família", 
        "capacidade" : "4", 
        "preco" : "250.00", 
        "ocupado" : "false"
    }
];
module.exports = listar;