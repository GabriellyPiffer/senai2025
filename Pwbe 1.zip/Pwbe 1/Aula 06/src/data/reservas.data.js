const listar = [
    { 
         "id": "1", 
         "clienteId": "1", 
         "quartoId": "101", 
         "checkIn": "2025-10-01", 
         "checkOut": "null"
 
    },
    { 
         "id": "2", 
         "clienteId": "2", 
         "quartoId": "102", 
         "checkIn": "2025-10-02", 
         "checkOut": "null"
 
    } 
]
module.exports = listar;