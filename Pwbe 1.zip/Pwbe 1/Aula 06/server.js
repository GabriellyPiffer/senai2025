const express = require("express"); 
const cors = require("cors");

const clienteRoutes = require("./src/routes/cliente.routes");
const app = express();

app.use(express.json());

app.use(cors());

app.use(clienteRoutes());

app.listen(3000, () => {
    console.log("Servidor online na porta 3000");
});